// Static site builder. No dependencies. Run: node build.mjs
// Reads every content/modules/module-*.json and writes ./dist
import { readFileSync, readdirSync, writeFileSync, mkdirSync, rmSync, cpSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const SITE = process.env.SITE_URL || 'https://learn.startupstairs.in';
const MAIN = 'https://startupstairs.in';
const YEAR = 2026;
const OUT = 'dist';

/* ---------- load content ---------- */
const modules = readdirSync('content/modules')
  .filter((f) => /^module-.*\.json$/.test(f))
  .map((f) => JSON.parse(readFileSync(join('content/modules', f), 'utf8')))
  .sort((a, b) => a.moduleNumber - b.moduleNumber);

/* ---------- helpers ---------- */
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const attr = (o) => esc(JSON.stringify(o));
const pad = (n) => String(n).padStart(2, '0');
const write = (path, html) => { const full = join(OUT, path); mkdirSync(join(full, '..'), { recursive: true }); writeFileSync(full, html); };
const stripTags = (s) => s.replace(/<[^>]+>/g, '');

/* ---------- layout ---------- */
function layout({ title, description, path, body, active = true }) {
  const url = SITE + path;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(description)}">
<link rel="canonical" href="${url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Startup Stairs Business School">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${url}">
<meta name="twitter:card" content="summary">
<link rel="icon" href="${MAIN}/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Lora:wght@500;600&family=Roboto:wght@400;500&display=swap">
<link rel="stylesheet" href="/assets/site.css">
</head>
<body>
<a href="#main" class="skip" style="position:absolute;left:-999px">Skip to content</a>
<header class="site-header"><div class="in">
  <a class="brand" href="/learn/">Startup Stairs <span class="label" style="letter-spacing:.06em">Learn</span></a>
  <nav class="site-nav" aria-label="Main">
    <a href="${MAIN}/startup-league-2026">Startup League</a>
    <a href="${MAIN}/acceleration-programme">Get Incubated</a>
    <a href="${MAIN}/startup-validation-sprint">Get Mentored</a>
    <a href="https://scorecard.startupstairs.in/">Scorecard</a>
    <a href="/learn/" aria-current="page">Learn</a>
  </nav>
</div></header>
<div id="main">
${body}
</div>
<footer class="site-footer"><div class="in">
  <span>&copy; ${YEAR} Startup Stairs Pvt. Ltd. DPIIT recognised incubator. NSDC International investee.</span>
  <span>Amounts are for teaching and are not financial advice.</span>
</div></footer>
<script src="/assets/learn.js" defer></script>
</body>
</html>`;
}

/* ---------- blocks ---------- */
function renderBlock(b, mod) {
  switch (b.type) {
    case 'paragraph': return `<p>${b.text}</p>`;
    case 'heading': return `<h2 id="${b.id}">${esc(b.text)}</h2>`;
    case 'formula': return `<div class="formula" role="math">${esc(b.text)}</div>`;
    case 'callout': return `<aside class="callout"><strong>${esc(b.title)}</strong><p>${b.text}</p></aside>`;
    case 'table': {
      const num = new Set(b.numeric || []);
      const head = b.columns.map((c, i) => `<th${num.has(i) ? ' class="r"' : ''}>${esc(c)}</th>`).join('');
      const rows = b.rows.map((r, ri) => {
        const cls = ri === b.emphasisRow ? ' class="em"' : '';
        return `<tr${cls}>${r.map((c, i) => `<td${num.has(i) ? ' class="r"' : ''}>${esc(c)}</td>`).join('')}</tr>`;
      }).join('');
      return `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table></div>`;
    }
    case 'calculator':
      return `<div data-calc="${attr(mod.presets)}"><div class="tabs" role="group" aria-label="Choose a business"></div><div class="panel"></div><noscript><p>Turn on JavaScript to use the calculator.</p></noscript></div>`;
    case 'examples':
      return `<div data-examples="${attr(mod.presets)}"><div class="tabs" role="group" aria-label="Choose an example"></div><div class="ex-grid"></div><noscript><p>Turn on JavaScript to see the examples.</p></noscript></div>`;
    case 'quiz': {
      const qs = b.questions.map((q) => `<div class="row"><label for="q-${q.id}">${esc(q.label)}</label><input class="field" id="q-${q.id}" type="number" inputmode="numeric"></div>`).join('');
      const cfg = { questions: b.questions, success: b.success, hint: b.hint, reveal: b.reveal };
      return `<div data-quiz="${attr(cfg)}"><form class="panel" novalidate>${qs}<div class="actions"><button class="btn" type="submit">Check answers</button><button class="btn sec" type="button" data-reveal>Show answers</button></div><p class="fb" aria-live="polite"></p></form></div>`;
    }
    default: throw new Error('Unknown block type: ' + b.type);
  }
}

function video(ch) {
  if (ch.videoId) {
    return `<div class="video"><iframe src="https://www.youtube-nocookie.com/embed/${esc(ch.videoId)}" title="${esc(ch.title)} video" loading="lazy" allow="accelerometer; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>`;
  }
  return `<div class="video"><span>Video coming soon</span></div>`;
}

/* ---------- pages ---------- */
const live = modules.filter((m) => m.status === 'live' && m.chapters.length);
const base = (m) => `/learn/${m.slug}/`;

function sidebar(mod, cur) {
  const items = mod.chapters.map((c, i) => `<li data-slug="${c.slug}"><a href="${base(mod)}${c.slug}/"${c.slug === cur ? ' aria-current="page"' : ''}><span class="n">${i + 1}</span><span>${esc(c.title)}</span><span class="ck" aria-hidden="true">&#10003;</span></a></li>`).join('');
  return { list: `<ol>${items}</ol>`, mod: `<a class="mod" href="${base(mod)}">Module ${mod.moduleNumber}: ${esc(mod.title)}</a>` };
}

// course home
write('learn/index.html', layout({
  title: 'Startup Stairs Business School: Free Startup Finance Course',
  description: 'Free, step-by-step modules on startup finance and unit economics for student founders, from Startup Stairs.',
  path: '/learn/',
  body: `<div class="narrow">
  <section class="intro">
    <p class="label">Startup Stairs Business School</p>
    <h1 style="margin-top:12px">Learn the numbers behind a startup.</h1>
    <p>Short chapters, simple English and real rupee examples. Read, watch the video, then practise. New modules are added as they are ready.</p>
  </section>
  <div class="list" role="list">
    ${modules.map((m) => {
      const isLive = m.status === 'live' && m.chapters.length;
      const inner = `<span class="no">${pad(m.moduleNumber)}</span><div><h3>${esc(m.title)}</h3><p>${esc(m.summary)}</p></div><span class="st${isLive ? ' live' : ''}">${isLive ? m.chapters.length + ' chapters' : 'Coming soon'}</span>`;
      return isLive ? `<a class="item" role="listitem" href="${base(m)}">${inner}</a>` : `<div class="item soon" role="listitem">${inner}</div>`;
    }).join('\n    ')}
  </div>
</div>`,
}));

// root redirect
write('index.html', `<!doctype html><meta charset="utf-8"><title>Startup Stairs Business School</title><meta http-equiv="refresh" content="0; url=/learn/"><link rel="canonical" href="${SITE}/learn/"><a href="/learn/">Go to the course</a>`);

for (const mod of live) {
  const total = mod.chapters.length;
  const mins = mod.chapters.reduce((t, c) => t + c.readMinutes, 0);
  const slugs = mod.chapters.map((c) => c.slug).join(',');

  // module overview
  write(`learn/${mod.slug}/index.html`, layout({
    title: `${mod.title} | Startup Stairs Business School`,
    description: mod.summary,
    path: base(mod),
    body: `<div class="narrow" data-module="${mod.slug}" data-total="${total}">
  <p class="crumbs"><a href="/learn/">All modules</a></p>
  <p class="label">Module ${mod.moduleNumber}</p>
  <h1 style="margin-top:10px">${esc(mod.title)}</h1>
  <p style="font-size:1.1rem;color:var(--muted);max-width:56ch">${esc(mod.summary)}</p>
  <div class="facts"><span><b>${total}</b>chapters</span><span><b>${mins}</b>minutes</span><span><b data-pct>0%</b>complete</span></div>
  <div class="cta-row"><a class="btn" data-continue data-slugs="${slugs}" data-base="${base(mod)}" href="${base(mod)}${mod.chapters[0].slug}/">Start module</a></div>
  <ol class="chapters">
    ${mod.chapters.map((c, i) => `<li data-slug="${c.slug}"><a href="${base(mod)}${c.slug}/"><span class="n">${pad(i + 1)}</span><h3>${esc(c.title)}</h3><span class="mins">${c.readMinutes} min</span><span class="ck" aria-hidden="true">&#10003;</span></a></li>`).join('\n    ')}
  </ol>
</div>`,
  }));

  // chapters
  mod.chapters.forEach((ch, i) => {
    const prev = mod.chapters[i - 1], next = mod.chapters[i + 1];
    const sb = sidebar(mod, ch.slug);
    const heads = ch.blocks.filter((b) => b.type === 'heading');
    const body = `<div class="layout" data-module="${mod.slug}" data-total="${total}">
  <nav class="sidebar" aria-label="Module chapters"><a class="back" href="/learn/">&larr; All modules</a>${sb.mod}${sb.list}</nav>
  <article class="article">
    <details class="mobile-toc"><summary>Chapters (${i + 1} of ${total})</summary>${sb.list.replace(/<span class="ck"/g, '<span class="ck"')}</details>
    <p class="crumbs"><a href="/learn/">Learn</a> / <a href="${base(mod)}">Module ${mod.moduleNumber}</a> / Chapter ${i + 1}</p>
    <h1>${esc(ch.title)}</h1>
    <p class="label" style="margin-top:12px">Chapter ${i + 1} of ${total} &middot; ${ch.readMinutes} min</p>
    ${video(ch)}
    ${ch.blocks.map((b) => renderBlock(b, mod)).join('\n    ')}
    <div class="takeaway"><strong>Key takeaway</strong><p>${ch.takeaway}</p></div>
    <div class="pager">
      <a class="btn sec" href="${prev ? base(mod) + prev.slug + '/' : base(mod)}">&larr; ${prev ? 'Previous' : 'Module overview'}</a>
      <div class="grp">
        <button class="btn sec" type="button" data-complete data-mod="${mod.slug}" data-chapter="${ch.slug}">Mark as complete</button>
        <a class="btn ${next ? '' : 'accent'}" href="${next ? base(mod) + next.slug + '/' : base(mod)}">${next ? 'Next chapter &rarr;' : 'Finish module'}</a>
      </div>
    </div>
  </article>
  <aside class="rail" aria-label="Chapter tools">
    <div class="box"><div class="label">Your progress</div><div class="pct" data-pct>0%</div><div class="meter"><i data-meter></i></div><p style="margin:8px 0 0;color:var(--muted)" data-count>0 of ${total} chapters done</p></div>
    ${heads.length ? `<div class="box otp"><div class="label" style="margin-bottom:6px">On this page</div>${heads.map((h) => `<a href="#${h.id}">${esc(h.text)}</a>`).join('')}</div>` : ''}
  </aside>
</div>`;
    write(`learn/${mod.slug}/${ch.slug}/index.html`, layout({
      title: `${ch.title} | ${mod.title} | Startup Stairs`,
      description: stripTags(ch.blocks.find((b) => b.type === 'paragraph')?.text || mod.summary).slice(0, 155),
      path: `${base(mod)}${ch.slug}/`,
      body,
    }));
  });
}

/* ---------- assets, sitemap, robots ---------- */
cpSync('assets', join(OUT, 'assets'), { recursive: true });
if (existsSync('public')) cpSync('public', OUT, { recursive: true });
const urls = ['/learn/', ...live.flatMap((m) => [base(m), ...m.chapters.map((c) => `${base(m)}${c.slug}/`)])];
write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${SITE}${u}</loc></url>`).join('\n')}\n</urlset>\n`);
write('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${SITE}/sitemap.xml\n`);
console.log(`Built ${urls.length} pages into ${OUT}/`);
