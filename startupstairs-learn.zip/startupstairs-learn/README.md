# Startup Stairs Business School

Free course pages for startupstairs.in. Plain static site, no npm packages needed.

## Run locally
```
npm run dev      # builds, then serves http://localhost:4321/learn/
node build.mjs   # build only (output in dist/)
```

## Add a new module
1. Copy `content/modules/module-01.json` to `module-02.json`.
2. Change `moduleNumber`, `slug`, `title`, `summary`, set `"status": "live"` and write the `chapters`.
3. Run `node build.mjs`. The module appears on /learn/ automatically.
Modules 2 to 5 already exist as "soon" stubs with no chapters. Fill them in and set status to live.

## Add a video
Upload to YouTube as Unlisted. Copy the ID (the part after `v=`) into that chapter's `"videoId"`.

## Add your logo
The header uses a text name. To use the logo, put `SS2.png` in `public/logos/` and replace the text in the `.brand` link inside `build.mjs`
with `<img src="/logos/SS2.png" alt="Startup Stairs">`.

## Deploy (Netlify)
Build command `node build.mjs`, publish folder `dist` (already in netlify.toml).
Set the env var `SITE_URL` to the final address (for example https://learn.startupstairs.in) so canonical links and sitemap are correct.
To host under startupstairs.in/learn instead, deploy `dist/learn` at that path.

## Notes
- Progress ticks are saved in the visitor's browser only (localStorage).
- Email capture, login and certificates are not included.
