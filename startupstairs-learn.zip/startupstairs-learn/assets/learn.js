/* Startup Stairs Business School: calculator, examples, quiz and progress. No dependencies. */
(function () {
  var KEY = "ss-learn-progress";
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function inr(n) {
    var s = Math.abs(Math.round(n)).toString(), last = s.slice(-3), rest = s.slice(0, -3);
    if (rest) last = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + last;
    return (n < 0 ? "−" : "") + "₹" + last;
  }
  function sum(costs) { return costs.reduce(function (t, c) { return t + c[1]; }, 0); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  /* progress (saved in this browser only) */
  var store = {};
  try { store = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { store = {}; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {} }
  function doneList(mod) { return store[mod] || []; }
  function paintProgress() {
    var root = $("[data-module]");
    if (!root) return;
    var mod = root.getAttribute("data-module"), total = +root.getAttribute("data-total") || 1, list = doneList(mod);
    $$("[data-slug]").forEach(function (el) { el.classList.toggle("done", list.indexOf(el.getAttribute("data-slug")) > -1); });
    var pct = Math.round(list.length / total * 100);
    $$("[data-pct]").forEach(function (el) { el.textContent = pct + "%"; });
    $$("[data-meter]").forEach(function (el) { el.style.width = pct + "%"; });
    $$("[data-count]").forEach(function (el) { el.textContent = list.length + " of " + total + " chapters done"; });
    var cont = $("[data-continue]");
    if (cont && list.length) {
      var next = cont.getAttribute("data-slugs").split(",").filter(function (s) { return list.indexOf(s) < 0; })[0];
      if (next) { cont.setAttribute("href", cont.getAttribute("data-base") + next + "/"); cont.textContent = "Continue"; }
    }
    var btn = $("[data-complete]");
    if (btn) {
      var d = list.indexOf(btn.getAttribute("data-chapter")) > -1;
      btn.textContent = d ? "Completed ✓" : "Mark as complete";
      btn.classList.toggle("done", d);
    }
  }
  function setDone(mod, ch, on) {
    var list = doneList(mod).filter(function (s) { return s !== ch; });
    if (on) list.push(ch);
    store[mod] = list; save(); paintProgress();
  }
  var cbtn = $("[data-complete]");
  if (cbtn) cbtn.addEventListener("click", function () {
    var mod = cbtn.getAttribute("data-mod"), ch = cbtn.getAttribute("data-chapter");
    setDone(mod, ch, doneList(mod).indexOf(ch) < 0);
  });

  /* calculator */
  $$("[data-calc]").forEach(function (root) {
    var presets = JSON.parse(root.getAttribute("data-calc")), cur, st;
    var tabs = $(".tabs", root), body = $(".panel", root);
    presets.forEach(function (p, i) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "tab"; b.textContent = p.name; b.setAttribute("aria-pressed", i === 0);
      b.addEventListener("click", function () { load(i); });
      tabs.appendChild(b);
    });
    function load(i) {
      cur = presets[i];
      st = { price: cur.price, costs: cur.costs.map(function (c) { return [c[0], c[1]]; }) };
      $$(".tab", tabs).forEach(function (b, j) { b.setAttribute("aria-pressed", i === j); });
      var h = '<div class="row"><label for="calc-price">Selling price (₹)</label><input class="field" id="calc-price" type="number" inputmode="numeric" min="0" value="' + st.price + '"></div>';
      st.costs.forEach(function (c, k) {
        h += '<div class="row"><label for="calc-c' + k + '">' + esc(c[0]) + '</label><input class="field" id="calc-c' + k + '" data-k="' + k + '" type="number" inputmode="numeric" min="0" value="' + c[1] + '"></div>';
      });
      h += '<div class="row sum"><span>Total cost per ' + esc(cur.unit) + '</span><span class="num" data-out="cost"></span></div>' +
        '<div class="result"><div><div class="label" data-out="label"></div><div class="big" data-out="profit"></div></div><div class="side" data-out="margin"></div></div>' +
        '<div class="split" aria-hidden="true"><i data-out="bcost"></i><i class="p" data-out="bprofit"></i></div>' +
        '<div class="legend"><span><b></b>Cost</span><span><b class="p"></b>Profit</span></div>';
      body.innerHTML = h;
      $("#calc-price", body).addEventListener("input", function (e) { st.price = Math.max(0, +e.target.value || 0); calc(); });
      $$("[data-k]", body).forEach(function (inp) { inp.addEventListener("input", function () { st.costs[+inp.getAttribute("data-k")][1] = Math.max(0, +inp.value || 0); calc(); }); });
      calc();
    }
    function out(k) { return $('[data-out="' + k + '"]', body); }
    function calc() {
      var tc = sum(st.costs), pr = st.price - tc;
      out("cost").textContent = inr(tc);
      var big = out("profit"); big.textContent = (pr > 0 ? "+" : "") + inr(pr); big.className = "big " + (pr >= 0 ? "pos" : "neg");
      out("label").textContent = (pr >= 0 ? "Profit" : "Loss") + " per " + cur.unit;
      out("margin").textContent = st.price > 0 ? (pr < 0 ? "\u2212" : "") + Math.abs(Math.round(pr / st.price * 100)) + "% of price" : "";
      var cw = st.price > 0 ? Math.min(100, tc / st.price * 100) : 100;
      out("bcost").style.width = cw + "%"; out("bprofit").style.width = (pr > 0 ? 100 - cw : 0) + "%";
    }
    load(0);
  });

  /* examples */
  $$("[data-examples]").forEach(function (root) {
    var presets = JSON.parse(root.getAttribute("data-examples")), tabs = $(".tabs", root), body = $(".ex-grid", root);
    presets.forEach(function (p, i) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "tab"; b.textContent = p.name; b.setAttribute("aria-pressed", i === 0);
      b.addEventListener("click", function () { show(i); });
      tabs.appendChild(b);
    });
    function show(i) {
      var p = presets[i], tc = sum(p.costs), pr = p.price - tc;
      $$(".tab", tabs).forEach(function (b, j) { b.setAttribute("aria-pressed", i === j); });
      var rows = '<tr><td>Selling price</td><td class="r">' + inr(p.price) + "</td></tr>";
      p.costs.forEach(function (c) { rows += "<tr><td>" + esc(c[0]) + '</td><td class="r">' + inr(c[1]) + "</td></tr>"; });
      rows += '<tr class="total"><td>Total cost</td><td class="r">' + inr(tc) + "</td></tr>";
      body.innerHTML = '<div class="table-wrap"><table><thead><tr><th>Particular</th><th class="r">Amount</th></tr></thead><tbody>' + rows + "</tbody></table></div>" +
        '<div class="ex-side"><span class="label">' + (pr >= 0 ? "Profit" : "Loss") + " per " + esc(p.unit) + '</span><span class="big ' + (pr >= 0 ? "pos" : "neg") + '">' + inr(pr) + "</span><p>" + inr(p.price) + " − " + inr(tc) + " = " + inr(pr) + ". " + esc(p.note) + "</p></div>";
    }
    show(0);
  });

  /* quiz */
  $$("[data-quiz]").forEach(function (root) {
    var cfg = JSON.parse(root.getAttribute("data-quiz")), fb = $(".fb", root);
    var form = $("form", root);
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = 0;
      cfg.questions.forEach(function (q) {
        var i = $("#q-" + q.id, root), good = i.value !== "" && +i.value === q.answer;
        i.className = "field " + (good ? "ok" : "no"); if (good) ok++;
      });
      fb.textContent = ok === cfg.questions.length ? cfg.success : ok + " of " + cfg.questions.length + " correct. " + cfg.hint;
      if (ok === cfg.questions.length) { var b = $("[data-complete]"); if (b) setDone(b.getAttribute("data-mod"), b.getAttribute("data-chapter"), true); }
    });
    $("[data-reveal]", root).addEventListener("click", function () {
      cfg.questions.forEach(function (q) { var i = $("#q-" + q.id, root); i.value = q.answer; i.className = "field ok"; });
      fb.textContent = cfg.reveal;
    });
  });

  paintProgress();
})();
