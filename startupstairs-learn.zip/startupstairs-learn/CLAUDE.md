# Startup Stairs Business School (learn section)

Static site. No dependencies. `node build.mjs` reads `content/modules/*.json` and writes `dist/`.
Preview: `npm run dev` then open http://localhost:4321/learn/

## Rules for every change
- Adding a module means adding ONE file: `content/modules/module-0N.json`. Do not edit build.mjs for content.
- Design: very clean, minimal, professional. Off-white page, navy text, orange only for the active chapter, links on hover, key takeaway rule and one primary action.
- Brand tokens (assets/site.css): navy #0F172B, orange #EA580C, background #FAFAFA, border #E3E7EE, muted #5B667D.
- Fonts: Lora for h1 and h2 only. Roboto for body. JetBrains Mono for rupee amounts and formulas.
- Do NOT add: emojis, gradients, shadows, rotated cards, mascots, confetti, decorative icons, animated play buttons.
- Radius 8px. Borders 1px. Motion only 150ms color changes. Respect prefers-reduced-motion.
- Writing: easy English, short sentences, no em dashes. Rupee amounts in Indian format (₹1,40,000).
- Accessibility: visible focus, aria-current on active chapter, AA contrast, no horizontal scroll at 375px.

## Block types (in a chapter's `blocks`)
paragraph, heading (id + text), table (columns, rows, numeric[], emphasisRow), formula, callout (title, text),
calculator and examples (use the module `presets`), quiz (questions with id, label, answer).
Each chapter also has slug, title, readMinutes, videoId (YouTube ID, optional) and takeaway.
